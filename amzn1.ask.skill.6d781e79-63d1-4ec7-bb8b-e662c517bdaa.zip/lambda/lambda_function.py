# -*- coding: utf-8 -*-

 #----------------------------------------------------------------------------------------------#
#------------------------------------------  IMPORTS ------------------------------------------#
#----------------------------------------------------------------------------------------------#
import logging
import ask_sdk_core.utils as ask_utils
import os
import requests
import calendar
from datetime import datetime

from ask_sdk_core.utils import get_supported_interfaces
import json
from ask_sdk_model.interfaces.alexa.presentation.apl import (
	    RenderDocumentDirective, ExecuteCommandsDirective, SpeakItemCommand,
	    AutoPageCommand, HighlightMode)

# Imports for algorithm
import requests
from bs4 import BeautifulSoup
from pronunciationDict import *

# Import the S3 Persistence adapter, create your S3 adapter and set you up with a bucket on S3 to store your data.
# An Amazon S3 bucket is a public cloud storage resource. A bucket is similar to a file folder for storing objects,
# which consists of data and descriptive metadata. This new dependency will allow you to use the AttributesManager
# to save and read user data using Amazon S3.
from ask_sdk_s3.adapter import S3Adapter
s3_adapter = S3Adapter(bucket_name=os.environ["S3_PERSISTENCE_BUCKET"])
from ask_sdk_core.skill_builder import CustomSkillBuilder

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.

from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def _load_apl_document(file_path):
    # type: (str) -> Dict[str, Any]
    """Load the apl json document at the path into a dict object."""
    with open(file_path) as f:
        return json.load(f)


class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool

        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        attr = handler_input.attributes_manager.persistent_attributes
        accent = attr["accent"]
        
        if accent != None:
            speak_output = "Welcome to World Accents. Currently I am speaking Southern. If you want, you can tell me to speak another accent."
            reprompt_text = "I natively speak General American English, but I can speak in Southern and British too. \
            Which one would you like me to use?"
            speak_output = '%s' % turnTextToSouthern(speak_output)
            reprompt_text = '"<s><phoneme alphabet="ipa" ph="wɪətʃ">which </phoneme><phoneme alphabet="ipa" ph="wəʌn">one </phoneme><phoneme alphabet="ipa" ph="wʊd"\
            >would </phoneme><phoneme alphabet="ipa" ph="juː">you </phoneme><phoneme alphabet="ipa" ph="laɛk">like </phoneme><phoneme alphabet="ipa" ph="mɪiː">me \
            </phoneme><phoneme alphabet="ipa" ph="tuː">to </phoneme><phoneme alphabet="ipa" ph="juːzəz">use?i </phoneme><phoneme alphabet="ipa" ph="ˈnɛitɪəvz">natively \
            </phoneme><phoneme alphabet="ipa" ph="spɪiːk">speak </phoneme><phoneme alphabet="ipa" ph="ˈdʒɪnərəl">general </phoneme><phoneme alphabet="ipa" ph="əˈmɛjərɪəkən">american \
            </phoneme><phoneme alphabet="ipa" ph="ˈɪəŋɡlɪəʃ">english </phoneme><phoneme alphabet="ipa" ph="bəʌt">but </phoneme><phoneme alphabet="ipa" ph="aɛ">i </phoneme>\
            <phoneme alphabet="ipa" ph="kajən">can </phoneme><phoneme alphabet="ipa" ph="spɪiːk">speak </phoneme><phoneme alphabet="ipa" ph="ɪən">in </phoneme><phoneme alphabet="ipa" ph=\
            "ˈsəʌðən">southern </phoneme><phoneme alphabet="ipa" ph="ajənd">and </phoneme><phoneme alphabet="ipa" ph="ˈbrɪətɪəʃ">british </phoneme><phoneme alphabet="ipa" ph="tuː">too \
            </phoneme></s> <s><phoneme alphabet="ipa" ph="wɪətʃ">which </phoneme><phoneme alphabet="ipa" ph="wəʌn">one </phoneme><phoneme alphabet="ipa" ph="wʊd">would </phoneme><phoneme alphabet=\
            "ipa" ph="juː">you </phoneme><phoneme alphabet="ipa" ph="laɛk">like </phoneme><phoneme alphabet="ipa" ph="mɪiː">me </phoneme><phoneme alphabet="ipa" ph="tuː"\
            >to </phoneme><phoneme alphabet="ipa" ph="juːz">use </phoneme></s>"'
        else:
            speak_output = "Welcome to World Accents. Currently I can speak: Southern. Which accent would you like me to use?"
            reprompt_text = "I natively speak General American English, but I can speak in Southern and British too. \
            Which one would you like me to use?"
        
        if get_supported_interfaces(handler_input).alexa_presentation_apl is not None: 
            return (
                handler_input.response_builder
                    .speak(speak_output)
                    .ask(reprompt_text)
                    .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("launchDocument.json"),
                            datasources=_load_apl_document("launchDataSources.json")
                        )
                    )
                    .response
                )

        else:
            speak_output = "You don't have a screen"
            return (
                handler_input.response_builder
                    .speak(speak_output)
                    .ask("Please buy an Alexa device with a screen")
                    .response
            )
        


        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(reprompt_text)
                .response
        )


class CaptureAccentIntentHandler(AbstractRequestHandler):
    """Handler for Capture Accent Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("CaptureAccentIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        slots = handler_input.request_envelope.request.intent.slots
        accent = slots["accent"].value
        
        
        # Now, tell Amazon S3 to save these values so the skill won't forget their birthday.
        # The SDK provides a useful mechanism for saving information across sessions: the AttributesManager.
        # The code tells the AttributesManager what the data is, and the manager sends it to Amazon S3.
        # With the manager, the skill can read the data from session to session and your read/write code
        # can remain the same, even if you change where you save your data later.
        attributes_manager = handler_input.attributes_manager
        
        # This piece of code is mapping the variables already declared in the code to corresponding variables
        # that will be created in Amazon S3 when the code runs. These variables are now declared as persistent
        # (they are local to the function in which they are declared, yet their values are retained in memory
        # between calls to the function). Now you can save the user's data to them. 
        accent_attributes = {
            "accent": accent
        }
        
       # Use the AttributesManager to set the data to save to Amazon S3.
        attributes_manager.persistent_attributes = accent_attributes
        attributes_manager.save_persistent_attributes()
        
        speak_output = "Thanks, what would you like me to say in %s? Respond with say, followed by the phrase you'd like me to say." % accent
        if accent == "southern":
            speak_output = "%s" % turnTextToSouthern(speak_output)
        # .ask("What would you like me to say?")
        
        return (
            handler_input.response_builder
                .speak(speak_output).response
        )

class CapturePhraseIntentHandler(AbstractRequestHandler):
    """Handler for Capture Phrase Intent."""
    
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        attr = handler_input.attributes_manager.persistent_attributes
        attributes_are_present = ("accent" in attr)
        return attributes_are_present and ask_utils.is_intent_name("CapturePhraseIntent")(handler_input)

    def handle(self, handler_input):
        
        slots = handler_input.request_envelope.request.intent.slots
        phrase = slots["phrase"].value
        
        # type: (HandlerInput) -> Response
        attr = handler_input.attributes_manager.persistent_attributes
        if "accent" in attr.keys():
            accent = attr["accent"]
        
        # Now, tell Amazon S3 to save these values so the skill won't forget their birthday.
        # The SDK provides a useful mechanism for saving information across sessions: the AttributesManager.
        # The code tells the AttributesManager what the data is, and the manager sends it to Amazon S3.
        # With the manager, the skill can read the data from session to session and your read/write code
        # can remain the same, even if you change where you save your data later.
        attributes_manager = handler_input.attributes_manager
        
        # This piece of code is mapping the variables already declared in the code to corresponding variables
        # that will be created in Amazon S3 when the code runs. These variables are now declared as persistent
        # (they are local to the function in which they are declared, yet their values are retained in memory
        # between calls to the function). Now you can save the user's data to them. 
        accent_attributes = {
            "accent": accent,
        }
        
       # Use the AttributesManager to set the data to save to Amazon S3.
        attributes_manager.persistent_attributes = accent_attributes
        attributes_manager.save_persistent_attributes()
        
        if accent == "southern":
            speak_output = '%s' % turnTextToSouthern(phrase)
            documentJSON = "southernDocument.json"
            dataSourcesJSON = "southernDataSources.json"
        else:
            speak_output = "Sorry, something went wonky."
            documentJSON = ""
            dataSourcesJSON = ""
        
        
            
        if get_supported_interfaces(handler_input).alexa_presentation_apl is not None: 
            return (
                handler_input.response_builder
                    .speak(speak_output)
                    .ask(speak_output)
                    .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document(documentJSON),
                            datasources=_load_apl_document(dataSourcesJSON)
                        )
                    )
                    .response
                )

        else:
            speak_output = "You don't have a screen"
            return (
                handler_input.response_builder
                    .speak(speak_output)
                    .ask("Please buy an Alexa device with a screen")
                    .response
            )
        
        
        handler_input.response_builder.speak(speak_output)

        return handler_input.response_builder.response


class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "You can say hello to me! How can I help?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Goodbye!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )

class FallbackIntentHandler(AbstractRequestHandler):
    """Single handler for Fallback Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.FallbackIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        logger.info("In FallbackIntentHandler")
        speech = "Hmm, I'm not sure. You can say Hello or Help. What would you like to do?"
        reprompt = "I didn't catch that. What can I help you with?"

        return handler_input.response_builder.speak(speech).ask(reprompt).response

class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        # Any cleanup logic goes here.

        return handler_input.response_builder.response


class IntentReflectorHandler(AbstractRequestHandler):
    """The intent reflector is used for interaction model testing and debugging.
    It will simply repeat the intent the user said. You can create custom handlers
    for your intents by defining them above, then also adding them to the request
    handler chain below.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("IntentRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        intent_name = ask_utils.get_intent_name(handler_input)
        speak_output = "You just triggered " + intent_name + "."

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speak_output = "Sorry, I had trouble doing what you asked. Please try again."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

# ------------------------------------------------------------------------------------------------------------------------
# ACTUAL ACCENT CODE PART
# ------------------------------------------------------------------------------------------------------------------------

def cleanHTMLToIPA(str):
    """
        Takes a line of HTML containing the desired IPA transcription.
        Removes HTML tags, remove "/"s, and remove spaces
    """
    inTag = False
    newStr = ""
    for char in str:
        if char == '<':
            inTag = True
        elif char == '>':
            inTag = False
        else:
            if inTag == False and char != "/" and char != " ":
                newStr += char
    return newStr

def removePunctuation(word):
    """
        Remove punctuation off of the end of a word
    """
    punctuation = [".",",","?","!",",",":",";"]
    if len(word) == 0:
        return "",""
    elif word[-1] in punctuation:
        return word[:-1], word[-1]
    else:
        return word, ""

def pluralize(ipa):
    """
        Take the ipa of a word and make it plural
    """
    if ipa[-1] in ["s","z","ʃ","ʒ"]:
        ipa += "əz"
    elif ipa[-1] in ["p","t","k","f","θ","x"]:
        ipa += "s"
    else:
        ipa += "z"
    return ipa

def getIPAs(word):
    if word in pronunciationDict.keys():
        entry = word
        ipaBrit = pronunciationDict[word][0]
        ipaUS = pronunciationDict[word][1]
        if ipaBrit != "None" or ipaUS != "None":
            return entry, ipaBrit, ipaUS
    entry, ipaBrit, ipaUS = getUnknownIPAs(word)
    print("Searching for unknown word: %s, %s, %s" %(entry, ipaBrit, ipaUS))
    return entry, ipaBrit, ipaUS

def getUnknownIPAs(word):
    r = requests.get('https://www.dictionary.com/browse/'+word)

    # Parsing the HTML
    soup = BeautifulSoup(r.content, 'html.parser')
    # print(soup.prettify())

    s = soup.find('h1', class_="css-1sprl0b e1wg9v5m5")
    entry = cleanHTMLToIPA(str(s)).lower()
    print("Entry: " + entry)

    s = soup.find('span', class_='pron')
    ipaBrit = cleanHTMLToIPA(str(s))
    print("British: " + ipaBrit)

    s = soup.find('span', class_="pron-ipa-content css-7iphl0 evh0tcl1")
    ipaUS = cleanHTMLToIPA(str(s).split(",")[0])
    print("US: " + ipaUS)

    # Deal with plurals
    if len(word) > len(entry): # Assume it's plural
        ipaBrit = pluralize(ipaBrit)
        ipaUS = pluralize(ipaUS)

    return entry, ipaBrit, ipaUS

def turnWordToSouthern(word):
    # Get the right base ipa
    entry, ipaBrit, ipaUS = getIPAs(word)
    if ipaBrit != "None":
        ipa = ipaBrit
    elif ipaUS != "None":
        ipa = ipaUS
    else:
        ipa = word

    # Loop through to create new ipa
    ipaSouth = ""
    i = 0
    while i < len(ipa):
        curr = ipa[i] # current character
        if i+1 < len(ipa):
            next = ipa[i+1] # next character
        else:
            next = ""
        toAdd = curr # the character to add to ipaSouth

        if curr + next == "aɪ":       # diphthongs start here
            toAdd = "aɛ"
            i += 1
        elif curr + next == "aʊ":
            toAdd = "æɔ" # Inaccurate but Alexa can't handle some sounds
            i += 1
        elif curr + next == "eɪ":
            toAdd = "ɛi"
            i += 1
        elif curr + next == "ɔɪ":
            toAdd = "oi"
            i += 1
        elif curr + next == "oʊ":
            if i+2 < len(ipa) and ipa[i+2] == "l":
                toAdd = "ɔu"
            else:
                toAdd = "əʊ"
            i += 1
        elif curr == "æ":           # pure vowels start here
            toAdd = "ajə"
        elif curr == "ɔ":
            toAdd = "a"
        elif curr == "ɛ":
            if next=="m" or next =="n":
                toAdd = "ɪ"
            else:
                toAdd = "ɛjə"
        elif curr == "ɪ":
            toAdd = "ɪə"
        elif curr == "i":
            if next == "ː":
                toAdd = "ɪi"
        elif curr == "ɜ" or curr == "ʌ":
            toAdd = "əʌ" # Inaccurate but Alexa can't handle some sounds
        elif curr == "uː":
            toAdd = "ʊu"

        ipaSouth += toAdd
        i += 1

    return ipaSouth

def turnTextToSouthern(text):
    wordList = text.split(" ")
    alexaText = "<s>"
    i = 0
    print(len(wordList))
    while i < len(wordList):
        currWord = wordList[i].lower()
        currWord, currPunct = removePunctuation(currWord)

        if i+1 < len(wordList):
            nextWord = " " + wordList[i+1].lower()
        else:
            nextWord = ""
        nextWord, nextPunct = removePunctuation(nextWord)

        punct = currPunct
        if currWord + nextWord in ["am not", "is not", "are not", "have not", "has not"]:
            currWord = "ain't"
            nextWord = ""
            punct = nextPunct
            i += 1
        elif currWord + nextWord == "shopping cart":
            currWord = "buggy"
            nextWord = ""
            punct = nextPunct
            i += 1
        elif currWord == "accompany" or currWord == "escort":
            currWord = "carry"
        elif currWord + nextWord == "goose bumps":
            currWord = "chill"
            nextWord = "bumps"
            punct = nextPunct
            i += 1
        else:
            print("Next word" + nextWord + " getting scrapped")
            nextWord = ""


        alexaText += '<phoneme alphabet="ipa" ph="' \
                    + turnWordToSouthern(currWord) \
                    + '">%s </phoneme>' % currWord
        if nextWord != "":
            alexaText += '<phoneme alphabet="ipa" ph="' \
                        + turnWordToSouthern(nextWord) \
                        + '">%s </phoneme>' % nextWord
        print("Just added " + currWord + nextWord)
        print("i = " + str(i))

        if punct == ".":
            alexaText += "</s> <s>"

        i += 1
        print("i = " + str(i))

    if alexaText[-3:] == "<s>":
        alexaText = alexaText[:-3]
    else:
        alexaText += "</s>"

    return alexaText


# ------------------------------------------------------------------------------------------------------------------------

# ------------------------------------------------------------------------------------------------------------------------





# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.


sb = CustomSkillBuilder(persistence_adapter=s3_adapter)

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(CapturePhraseIntentHandler())
sb.add_request_handler(CaptureAccentIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(FallbackIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())
sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers

sb.add_exception_handler(CatchAllExceptionHandler())

lambda_handler = sb.lambda_handler()